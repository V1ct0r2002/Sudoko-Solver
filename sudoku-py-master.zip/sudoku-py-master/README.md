# Sudoku Python

## Description
PyGame implementation of Sudoku. Uses recursive backtracking to implement solving algorithm.

## Author 
Emil Soleymani
